## 微信视频号“笑来”中的内容

请在微信中搜索并关注微信视频号：“笑来”，或直接微信识别以下二维码关注……

![](wxvideo.jpg)


-----


<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/hiam9s" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/ewyuy4" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/rsmo56" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/sh8v9u" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/behnbc" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/oupo8c" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/carle2" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/k8y8ve" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/lnccqm" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/prnl6a" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/nsnv8c" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/oph434" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/4phwus" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/bjlkug" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/ry7hij" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/o1d3gb" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/21upqr" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/mxyofh" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/wdkd6b" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/35bzex" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/1vuy8n" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/mky356" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/a71uls" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/l1ap3d" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/c8ii9b" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/mnh0cl" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/u4zdgv" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/4szcnc" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/fp3apd" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/3iesub" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----

<div style="width:100%;height:0px;position:relative;padding-bottom:116.694%;"><iframe src="https://streamable.com/e/n09vu0" frameborder="0" width="100%" height="100%" allowfullscreen style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>

-----
