# INBlockchain ICO Investing Principles
